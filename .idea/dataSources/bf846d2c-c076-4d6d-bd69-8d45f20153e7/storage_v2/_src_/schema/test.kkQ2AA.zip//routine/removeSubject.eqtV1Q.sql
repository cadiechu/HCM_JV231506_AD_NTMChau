create
    definer = root@localhost procedure removeSubject(IN removeId int)
begin
    delete from subject where id = removeId;
end;

