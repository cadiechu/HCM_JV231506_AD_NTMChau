create
    definer = root@localhost procedure updateStudent(IN newid int, IN newname varchar(150), IN newemail varchar(100),
                                                     IN newphone varchar(50), IN newgender tinyint, IN newclassid int,
                                                     IN newbirthday date)
begin
    update student set name = newname where id = newid;
    update student set email = newemail where id = newemail;
    update student set phone = newname where id = newphone;
    update student set gender = newname where id = newgender;
    update student set class_room_id = newname where id = newclassid;
    update student set birthday = newname where id = newbirthday;
end;

