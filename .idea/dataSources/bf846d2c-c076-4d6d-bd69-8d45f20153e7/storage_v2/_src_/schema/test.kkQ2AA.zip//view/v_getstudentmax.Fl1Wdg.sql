create definer = root@localhost view v_getstudentmax as
select `s`.`id`            AS `id`,
       `s`.`name`          AS `name`,
       `s`.`email`         AS `email`,
       `s`.`phone`         AS `phone`,
       `s`.`gender`        AS `gender`,
       `s`.`class_room_id` AS `class_room_id`,
       `s`.`birthday`      AS `birthday`,
       `m`.`student_id`    AS `student_id`,
       `m`.`subject_id`    AS `subject_id`,
       `m`.`score`         AS `score`
from (`test`.`student` `s` join `test`.`mark` `m` on ((`s`.`id` = `m`.`student_id`)));

