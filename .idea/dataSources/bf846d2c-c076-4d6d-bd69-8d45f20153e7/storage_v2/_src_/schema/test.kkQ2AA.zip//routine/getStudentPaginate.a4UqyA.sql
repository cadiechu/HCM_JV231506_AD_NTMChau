create
    definer = root@localhost procedure getStudentPaginate(IN currentPage int, IN limitPaginate int)
begin
    declare
        page int;
    set page = (currentPage - 1) * limitPaginate;
    select s.id,
           s.name,
           s.Email,
           s.Phone,
           s.Gender,
           s.BirthDay,
           cr.name
    from student s
             join class_room cr on s.class_room_id = cr.id
    limit limitPaginate offset page;
end;

