create
    definer = root@localhost procedure update_classroom(IN newname varchar(200), IN newstart date, IN newend date)
begin
    insert into class_room (name, total_student, start_date, end_date)
    values (newname, null, newstart, newend);
end;

